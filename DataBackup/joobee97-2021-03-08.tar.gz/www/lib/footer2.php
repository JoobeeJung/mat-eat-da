<div id="footer">
<img src="../img/footer2.png" style="width:100%; height:250px;">
</div>